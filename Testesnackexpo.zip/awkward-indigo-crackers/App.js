import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Button } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {

function nome(){

  alert("Meu nome é TATA")
}


  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Ola mundo do react Native
      </Text>
      <Button mode="contained" style={styles.bg} onPress={()=>{nome()}}>Clique aqui</Button>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bg: {
    fontSize: 28,
    fontWeight: 'bold',
    TextColor: 'white',
  },
});
